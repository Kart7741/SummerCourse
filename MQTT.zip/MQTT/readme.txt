# -*- coding: utf-8 -*-
"""
Created on Mon Dec 11 07:52:24 2017

@author: ASUS
"""
Installatoin:
pip install paho-mqtt

Example:
    1. subscriber
    2. publisher
    3. backend#1
    4. backend#2
    

Installatoin of Node-red:

1. install Node.js, node-red
    
2. run node-red in command mode
    path: command mode > node-red
          browser > http://127.0.0.1:1880    

3. install nodes in node-red
    path: from palette-> user-setting->install->palette search for 
    item: node-red-dashboard, input-split 

4. import flows
    path:  import-> library 
    item: Control.json, Monitor.json

    